This package provides the interaction between nx and uds
