This package provides the actor needed for using with UDS infrastructure.
